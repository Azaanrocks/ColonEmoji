'use strict';
/* ColonEmoji toolbar popup — cross-browser MV3. No "tabs" permission needed:
   we only need tab.id, then ask the content script for site info. */
const api = globalThis.browser ?? globalThis.chrome;

const $ = id => document.getElementById(id);
let tabId = null;
let state = null;

function activeTab() {
  return api.tabs.query({ active: true, currentWindow: true }).then(tabs => tabs && tabs[0] ? tabs[0] : null);
}

function send(msg) {
  if (tabId == null) return Promise.resolve(null);
  return api.tabs.sendMessage(tabId, msg).catch(() => null);
}

/* badge: "OFF" while disabled for this tab, empty when enabled */
function setBadge(text) {
  if (tabId == null || !api.action || !api.action.setBadgeText) return;
  try {
    const opts = { tabId, text: text || '' };
    if (text) { opts.backgroundColor = '#4e5058'; opts.color = '#ffffff'; }
    api.action.setBadgeText(opts).catch(() => {
      try { api.action.setBadgeText({ text: text || '' }); } catch (e) { /* ignore */ }
    });
  } catch (e) { /* ignore */ }
}

function render() {
  if (!state) {
    $('main').hidden = true;
    $('note').hidden = false;
    setBadge('');
    return;
  }
  $('main').hidden = false;
  $('note').hidden = true;
  $('global').checked = state.enabled;
  $('site').checked = !!state.siteOn;
  $('site').disabled = !state.enabled;
  $('host').textContent = state.host || '';
  /* Feature 2 override switch: only relevant on blocklisted sites */
  const showForce = !!(state.blocklisted || state.forceEnabled);
  $('forceWrap').hidden = !showForce;
  if (showForce) $('force').checked = !!state.forceEnabled;
  setBadge(state.siteOn ? '' : 'OFF');
}

function update(next) {
  state = Object.assign({}, state, next);
  render();
}

activeTab().then(tab => {
  if (!tab) return;
  tabId = tab.id;
  return send({ type: 'colonemoji:status' }).then(s => { state = s; });
}).then(render).catch(render);

$('global').addEventListener('change', e => {
  const v = e.target.checked;
  send({ type: 'colonemoji:setEnabled', value: v }).then(s => {
    if (s) update({ enabled: v, siteOn: v && !state.siteDisabled, blocklisted: state.blocklisted });
    else render();
  });
});

$('site').addEventListener('change', e => {
  const v = e.target.checked;
  send({ type: 'colonemoji:setSite', value: !v }).then(s => {
    if (s) update({ siteDisabled: !v, siteOn: v && state.enabled });
    else render();
  });
});

$('force').addEventListener('change', e => {
  const v = e.target.checked;
  send({ type: 'colonemoji:setForce', value: v }).then(s => {
    if (s) update({ forceEnabled: v, siteOn: state.enabled && (v || !state.siteDisabled) });
    else render();
  });
});

$('opts').addEventListener('click', e => {
  e.preventDefault();
  api.runtime.openOptionsPage();
});
