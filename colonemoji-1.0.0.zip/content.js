'use strict';
/* ColonEmoji content script — cross-browser (Chromium/Firefox) MV3.
   No network calls except lazy-load of bundled emoji.json and custom emoji <img>s. */
const api = globalThis.browser ?? globalThis.chrome;

/* Sites that ship their own ":" autocomplete — off by default (Feature 2). */
const DEFAULT_BLOCKLIST = [
  'discord.com', 'slack.com', 'github.com', 'gitlab.com', 'notion.so', 'linear.app',
  'web.whatsapp.com', 'teams.microsoft.com', 'teams.live.com', 'teams.cloud.microsoft',
  'chat.google.com', 'mail.google.com', 'web.telegram.org', 'app.element.io',
  'twitch.tv', 'zulipchat.com'
];
/* Feature 4 defaults: shipped alias/hidden entries (editable in Options). */
const DEFAULT_ALIASES = { palestine: '\u{1F1F5}\u{1F1F8}', palestinian: '\u{1F1F5}\u{1F1F8}', palastine: '\u{1F1F5}\u{1F1F8}' };
const DEFAULT_HIDDEN = [];

/* ------------------------------------------------------------------ config */

const DEFAULTS = {
  trigger: ':',              // autocomplete trigger char
  pickerChar: '',            // optional separate picker char
  minChars: 2,               // min query chars before autocomplete shows
  insertFormat: 'emoji',     // 'emoji' | 'shortcode'  -> 🔥 or :fire:
  insertKeys: 'both',        // 'tab' | 'enter' | 'both'
  customInsertFormat: 'markup', // 'markup' | 'url'
  disabledSites: [],         // hostnames or "*.domain.tld"
  enabledSites: [],          // force-enable overrides (beat everything)
  blockedSites: DEFAULT_BLOCKLIST.slice(), // sites with their own ":" popup
  learnRanking: true,        // usage-based smart ranking
  customAliases: Object.assign({}, DEFAULT_ALIASES), // alias -> emoji char
  hiddenEmojis: DEFAULT_HIDDEN.slice(),             // chars or shortcodes
  closeShortcode: true,     // ":name:" auto-converts to the emoji (Discord-style)
  enabled: true              // global toggle
};

const MAX_RESULTS = 8;
const MAX_RECENTS = 24;
const MAX_PICKER_ITEMS = 400;
const TONES = ['', '\u{1F3FB}', '\u{1F3FC}', '\u{1F3FD}', '\u{1F3FE}', '\u{1F3FF}'];
const TONE_NAMES = ['None', 'Light', 'Medium-Light', 'Medium', 'Medium-Dark', 'Dark'];
const TONE_SWATCH = ['#4e5058', '#e8b78d', '#edc09b', '#d29d77', '#a86c47', '#784b30'];
const CATEGORIES = [
  ['Smileys & Emotion', 'Smileys'],
  ['People & Body', 'People'],
  ['Animals & Nature', 'Animals'],
  ['Food & Drink', 'Food'],
  ['Travel & Places', 'Travel'],
  ['Activities', 'Activities'],
  ['Objects', 'Objects'],
  ['Symbols', 'Symbols'],
  ['Flags', 'Flags']
];
const WORD_RE = /[A-Za-z0-9_+-]/;

/* Feature 1 constants */
const HALF_LIFE_DAYS = 14;      // frecency halves every 14 days
const MAX_PREFIX_PICKS = 200;
const FREQUENT_COUNT = 12;      // "Frequently used" row length
/* match tiers (higher wins) */
const T_NONE = 0, T_FUZZY = 1, T_SUBSTR = 2, T_WORDPREFIX = 3, T_PREFIX = 4, T_EXACT = 5;

const state = {
  settings: Object.assign({}, DEFAULTS),
  custom: [],
  recents: [],
  tone: 0,
  usage: {},          // { [shortcode]: {count, lastUsed} }   (local, Feature 1)
  prefixPicks: {},    // { [typedPrefix]: shortcode }          (local, Feature 1)
  raw: null,          // raw gemoji json, kept for index rebuilds
  index: null,          // built once
  loading: null,
  mode: 'none',         // 'none' | 'auto' | 'picker'
  el: null,
  queryStart: 0,
  queryEnd: 0,
  results: [],
  sel: 0,
  saved: null,          // {el,start,end} | {el,range}
  pickerQuery: '',
  pickerCat: 'recents',
  pickerItems: [],
  pickerSel: 0,
  pickerFreq: [],
  undo: null,           // one-step undo of a ":name:" -> emoji conversion
  lastQuery: null,
  lastNoticeAt: 0,   // Feature 2: disabled-site notice throttle (once / 60s / tab)
  composing: false,
  lastKey: ''
};

/* ------------------------------------------------------------------ storage */

function loadAll() {
  return Promise.all([
    api.storage.sync.get({ settings: DEFAULTS }).then(r => {
      state.settings = Object.assign({}, DEFAULTS, r.settings || {});
    }),
    api.storage.local.get({ customEmojis: [], recents: [], tone: 0, usage: {}, prefixPicks: {} }).then(r => {
      state.custom = Array.isArray(r.customEmojis) ? r.customEmojis : [];
      state.recents = Array.isArray(r.recents) ? r.recents : [];
      state.tone = r.tone | 0;
      state.usage = r.usage && typeof r.usage === 'object' ? r.usage : {};
      state.prefixPicks = r.prefixPicks && typeof r.prefixPicks === 'object' ? r.prefixPicks : {};
    })
  ]).catch(() => {});
}

function saveSettings() {
  api.storage.sync.set({ settings: state.settings }).catch(() => {});
}

api.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.settings) {
    const old = state.settings;
    state.settings = Object.assign({}, DEFAULTS, changes.settings.newValue || {});
    const idxChanged = JSON.stringify(old.customAliases) !== JSON.stringify(state.settings.customAliases) ||
      JSON.stringify(old.hiddenEmojis) !== JSON.stringify(state.settings.hiddenEmojis);
    if (idxChanged) rebuildIndex();          // aliases/hidden changed -> live rebuild
    if (!siteEnabled()) closeAll(false);
  } else if (area === 'local') {
    if (changes.customEmojis) state.custom = changes.customEmojis.newValue || [];
    if (changes.recents) state.recents = changes.recents.newValue || [];
    if (changes.tone) state.tone = changes.tone.newValue | 0;
    if (changes.usage) state.usage = changes.usage.newValue || {};
    if (changes.prefixPicks) state.prefixPicks = changes.prefixPicks.newValue || {};
    if (state.mode === 'picker') renderPicker();
  }
});

/* ------------------------------------------------------------------- domain */

function hostMatches(host, list) {
  for (const raw of (list || [])) {
    let p = String(raw || '').trim().toLowerCase();
    if (!p) continue;
    if (p.startsWith('*.')) p = p.slice(2);
    if (host === p || host.endsWith('.' + p)) return true;
  }
  return false;
}

function isSiteDisabled(host) {
  return hostMatches(host, state.settings.disabledSites);
}

function isForceEnabled(host) {
  return hostMatches(host, state.settings.enabledSites);
}

function isBlocklisted() {
  const host = location.hostname;
  return !isForceEnabled(host) && hostMatches(host, state.settings.blockedSites);
}

/* Precedence (highest wins): enabledSites override > disabledSites >
   default blocklist > global toggle. */
function siteEnabled() {
  const s = state.settings;
  const host = location.hostname;
  if (isForceEnabled(host)) return true;
  if (hostMatches(host, s.disabledSites)) return false;
  if (hostMatches(host, s.blockedSites)) return false;
  return !!s.enabled;
}

/* --------------------------------------------------------------- emoji data */

function ensureData() {
  if (state.index) return Promise.resolve(state.index);
  if (state.loading) return state.loading;
  state.loading = fetch(api.runtime.getURL('emoji.json'))
    .then(r => r.json())
    .then(json => { state.raw = json; state.index = buildIndex(json); return state.index; })
    .catch(() => { state.loading = null; return null; });
  return state.loading;
}

/* Rebuild only when aliases/hidden lists change (never on a timer). */
function rebuildIndex() {
  if (!state.raw) return;
  state.index = buildIndex(state.raw);
}

/* ISO 3166 alpha-2 from a regional-indicator pair, e.g. 🇵🇸 -> "ps" */
function flagCode(ch) {
  const cp = ch.codePointAt(0);
  if (cp < 0x1F1E6 || cp > 0x1F1FF) return '';
  const cp2 = ch.codePointAt(ch.length > 1 ? 2 : 0);
  if (cp2 < 0x1F1E6 || cp2 > 0x1F1FF) return '';
  return String.fromCharCode(97 + (cp - 0x1F1E6)) + String.fromCharCode(97 + (cp2 - 0x1F1E6));
}

/* normalize hidden list entries ("israel" / "🇮🇱") to emoji chars */
function hiddenCharSet() {
  const set = new Set();
  for (const raw of (state.settings.hiddenEmojis || [])) {
    const v = String(raw || '').trim().toLowerCase();
    if (!v) continue;
    if (state.index && state.index.byName[v]) set.add(state.index.byName[v].ch);
    else set.add(String(raw).trim());
  }
  return set;
}

function buildIndex(json) {
  const list = [];
  const byName = Object.create(null);
  const aliases = state.settings.customAliases || {};
  for (const e of json) {
    if (!e || !e.emoji || !Array.isArray(e.aliases) || !e.aliases.length) continue;
    const keys = [];
    for (const a of e.aliases) keys.push([String(a).toLowerCase(), 100]);
    if (e.description) keys.push([String(e.description).toLowerCase(), 70]);
    for (const t of (e.tags || [])) keys.push([String(t).toLowerCase(), 50]);
    /* Feature 4: every flag also answers to flag_<cc> and <cc> (Discord-style) */
    const code = e.category === 'Flags' ? flagCode(e.emoji) : '';
    if (code) {
      keys.push(['flag_' + code, 110]);
      if (!byName[code]) keys.push([code, 105]);
    }
    const item = {
      type: 'unicode', ch: e.emoji, name: e.aliases[0],
      cat: e.category, skin: !!e.skin_tones, keys
    };
    list.push(item);
    for (const a of e.aliases) byName[String(a).toLowerCase()] = item;
    if (code) { byName['flag_' + code] = item; if (!byName[code]) byName[code] = item; }
  }
  /* Feature 4: user-defined aliases merge into the same entries, so usage
     recorded under an alias counts toward the real emoji automatically. */
  for (const alias of Object.keys(aliases)) {
    const target = byName[String(aliases[alias]).toLowerCase()] ||
      list.find(it => it.ch === aliases[alias]);
    if (!target) continue;
    const a = String(alias).toLowerCase();
    if (!byName[a]) byName[a] = target;
    target.keys.push([a, 115]);
  }
  /* Feature 4: hidden emoji vanish from search, picker and ranking */
  const hidden = hiddenCharSet();
  const filtered = list.filter(it => !hidden.has(it.ch));
  filtered.byName = Object.create(null);
  for (const k of Object.keys(byName)) if (!hidden.has(byName[k].ch)) filtered.byName[k] = byName[k];
  return filtered;
}

function indexReady() { return !!state.index; }

/* custom emoji helpers */
function customItem(c) {
  return { type: 'custom', name: c.name, id: c.id, animated: !!c.animated };
}
function customUrl(c) {
  return 'https://cdn.discordapp.com/emojis/' + c.id + (c.animated ? '.gif' : '.png');
}

/* ------------------------------------------------------------------- search */

function fuzzySubseq(k, q) {
  let i = 0;
  for (let j = 0; j < k.length && i < q.length; j++) if (k[j] === q[i]) i++;
  return i === q.length;
}

/* match tier for one key (Feature 1 ordering): exact > prefix > word-prefix
   (after "_" "-" " " "+") > substring > fuzzy-subsequence */
function tierFor(k, q) {
  if (k === q) return T_EXACT;
  if (k.startsWith(q)) return T_PREFIX;
  const wi = k.indexOf(q);
  if (wi > 0) {
    const prev = k[wi - 1];
    if (prev === '_' || prev === '-' || prev === ' ' || prev === '+') return T_WORDPREFIX;
    return T_SUBSTR;
  }
  if (q.length >= 3 && fuzzySubseq(k, q)) return T_FUZZY;
  return T_NONE;
}

function tierOfKeys(keys, q) {
  let best = T_NONE;
  for (let i = 0; i < keys.length; i++) {
    const t = tierFor(keys[i][0], q);
    if (t > best) best = t;
  }
  return best;
}

/* ------------------------------------------------------------------- usage */

function frecency(name) {
  if (!state.settings.learnRanking) return 0;
  const u = state.usage[name];
  if (!u) return 0;
  const ageDays = Math.max(0, (Date.now() - (u.lastUsed || 0)) / 86400000);
  return (u.count || 0) * Math.pow(0.5, ageDays / HALF_LIFE_DAYS);
}

/* called on every insert (autocomplete and picker) */
function bumpUsage(item, typedPrefix) {
  const name = item.name;
  if (state.settings.learnRanking) {
    const u = state.usage[name] || { count: 0, lastUsed: 0 };
    u.count = (u.count || 0) + 1;
    u.lastUsed = Date.now();
    state.usage[name] = u;
    if (typedPrefix && typedPrefix.length >= 1 && typedPrefix.length <= 24) {
      state.prefixPicks[typedPrefix] = name;
      const keys = Object.keys(state.prefixPicks);
      if (keys.length > MAX_PREFIX_PICKS) delete state.prefixPicks[keys[0]];
    }
    api.storage.local.set({ usage: state.usage, prefixPicks: state.prefixPicks }).catch(() => {});
  }
}

function frequentItems(limit) {
  if (!state.settings.learnRanking) return [];
  const scored = [];
  for (const name of Object.keys(state.usage)) {
    const f = frecency(name);
    if (f <= 0) continue;
    const it = itemByName(name);
    if (it) scored.push({ it, f });
  }
  scored.sort((a, b) => (b.f - a.f) || (a.it.name < b.it.name ? -1 : 1));
  return scored.slice(0, limit || FREQUENT_COUNT).map(s => s.it);
}

function itemByName(name) {
  if (state.index && state.index.byName[name]) return state.index.byName[name];
  const c = state.custom.find(x => x.name === name);
  return c ? customItem(c) : null;
}

const recentSetCache = { key: null, set: null };
function recentSet() {
  if (recentSetCache.key !== state.recents.join('\u0001')) {
    recentSetCache.key = state.recents.join('\u0001');
    recentSetCache.set = new Set(state.recents);
  }
  return recentSetCache.set;
}
void recentSet;   /* recents now feed the picker tab; ranking uses usage data */

/* Sort: match tier, then remembered pick for this exact prefix, then
   frecency, then alphabetical (Feature 1). */
function searchEmoji(q, limit) {
  if (!state.index) return [];
  q = q.toLowerCase();
  const picked = state.settings.learnRanking ? (state.prefixPicks[q] || '') : '';
  const out = [];
  for (const it of state.index) {
    const t = tierOfKeys(it.keys, q);
    if (t > T_NONE) out.push({ it, t });
  }
  for (const c of state.custom) {
    const t = tierFor(String(c.name).toLowerCase(), q);
    if (t > T_NONE) out.push({ it: customItem(c), t });
  }
  out.sort((a, b) => {
    if (b.t !== a.t) return b.t - a.t;
    const ap = picked && a.it.name === picked ? 1 : 0;
    const bp = picked && b.it.name === picked ? 1 : 0;
    if (ap !== bp) return bp - ap;
    const af = frecency(a.it.name), bf = frecency(b.it.name);
    if (af !== bf) return bf - af;
    return a.it.name < b.it.name ? -1 : (a.it.name > b.it.name ? 1 : 0);
  });
  return out.slice(0, limit || MAX_RESULTS).map(o => o.it);
}

function itemFromToken(tok) {
  if (!tok) return null;
  if (tok.startsWith('u:')) return state.index ? state.index.byName[tok.slice(2)] || null : null;
  if (tok.startsWith('c:')) {
    const n = tok.slice(2);
    const c = state.custom.find(x => x.name === n);
    return c ? customItem(c) : null;
  }
  return null;
}

function pushRecent(item) {
  const tok = item.type === 'custom' ? 'c:' + item.name : 'u:' + item.name;
  const i = state.recents.indexOf(tok);
  if (i >= 0) state.recents.splice(i, 1);
  state.recents.unshift(tok);
  if (state.recents.length > MAX_RECENTS) state.recents.length = MAX_RECENTS;
  api.storage.local.set({ recents: state.recents }).catch(() => {});
}

function applyTone(ch, skin) {
  return skin && state.tone > 0 ? ch + TONES[state.tone] : ch;
}

function insertTextFor(item) {
  if (item.type === 'custom') {
    if (state.settings.customInsertFormat === 'url') return customUrl(item);
    return item.animated ? '<a:' + item.name + ':' + item.id + '>' : '<:' + item.name + ':' + item.id + '>';
  }
  if (state.settings.insertFormat === 'shortcode') return ':' + item.name + ':';
  return applyTone(item.ch, item.skin);
}

/* ---------------------------------------------------------- editable fields */

function realTarget(e) {
  if (e.composedPath) { const p = e.composedPath(); if (p && p.length) return p[0]; }
  return e.target;
}

const CC_RE = /(card|cvc|cvv|ccnum|cc-num|expir|security.?code)/i;

function isTextField(el) {
  const t = el.tagName;
  if (t === 'TEXTAREA') return true;
  if (t === 'INPUT') {
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    if (type === 'password') return false;
    if (['text', 'search', 'email', 'url', 'tel'].includes(type)) {
      if ((el.getAttribute('autocomplete') || '').toLowerCase() === 'off') {
        const hint = (el.name || '') + (el.id || '') + (el.placeholder || '') + (el.getAttribute('aria-label') || '');
        if (CC_RE.test(hint)) return false;
      }
      return true;
    }
  }
  return false;
}

function isEditable(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.hasAttribute && el.hasAttribute('data-colonemoji-input')) return false;
  if (el.disabled || el.readOnly) return false;
  if (el.isContentEditable) return true;
  return isTextField(el);
}

/* text offset helpers for contenteditable */
function caretTextPos(el) {
  const sel = window.getSelection();
  if (!sel || !sel.rangeCount) return -1;
  const r = sel.getRangeAt(0);
  if (!el.contains(r.startContainer)) return -1;
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let acc = 0, n;
  while ((n = walker.nextNode())) {
    if (n === r.startContainer) return acc + r.startOffset;
    acc += n.nodeValue.length;
  }
  return acc;
}

function pointAt(root, offset) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let acc = 0, n;
  while ((n = walker.nextNode())) {
    const len = n.nodeValue.length;
    if (acc + len >= offset) return { node: n, offset: Math.max(0, offset - acc) };
    acc += len;
  }
  return null;
}

function caretInfo(el) {
  if (isTextField(el)) {
    const pos = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
    return { value: el.value, pos };
  }
  const pos = caretTextPos(el);
  if (pos < 0) return null;
  const sel = window.getSelection();
  const range = sel.getRangeAt(0).cloneRange();
  return { value: rangeToStringBefore(el, range), pos, range };
}

function rangeToStringBefore(root, range) {
  const r = range.cloneRange();
  r.selectNodeContents(root);
  r.setEnd(range.startContainer, range.startOffset);
  return r.toString();
}

/* ------------------------------------------------------- trigger detection */

function parseTrigger(text, pos) {
  const s = state.settings;
  const trig = s.trigger || ':';

  // separate picker character: "<p>query"
  if (s.pickerChar && s.pickerChar !== trig) {
    let i = pos, n = 0;
    while (i > 0 && n < 40 && WORD_RE.test(text[i - 1])) { i--; n++; }
    if (i > 0 && text[i - 1] === s.pickerChar) {
      return { type: 'picker', start: i - 1, end: pos, q: text.slice(i, pos) };
    }
  }

  let i = pos, n = 0;
  while (i > 0 && n < 40 && WORD_RE.test(text[i - 1])) { i--; n++; }
  if (i === 0 || text[i - 1] !== trig) return null;
  const q = text.slice(i, pos);
  if (q.length === 0) {
    if (i - 1 >= 0 && text[i - 2] === trig) {
      return { type: 'picker', start: i - 2, end: pos, q: '' };  // "::"
    }
    return null;  // bare trigger, nothing to match yet
  }
  return { type: 'auto', start: i - 1, end: pos, q };
}

/* ------------------------------------------------------- caret measurement */

let mirror = null;
const MIRROR_PROPS = [
  'fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'fontVariant',
  'letterSpacing', 'lineHeight', 'wordSpacing', 'textTransform', 'textIndent',
  'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
  'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
  'direction', 'textAlign', 'tabSize'
];

function caretRectInput(el, pos) {
  const cs = getComputedStyle(el);
  const rect = el.getBoundingClientRect();
  if (!mirror || !mirror.isConnected) {
    mirror = document.createElement('div');
    mirror.setAttribute('aria-hidden', 'true');
    mirror.style.cssText = 'position:absolute;left:-99999px;top:0;visibility:hidden;pointer-events:none;' +
      'height:auto;min-height:0;max-height:none;overflow:hidden;box-sizing:border-box;white-space:pre-wrap;overflow-wrap:break-word;';
    (document.documentElement || document.body).appendChild(mirror);
  }
  for (const p of MIRROR_PROPS) {
    const v = cs.getPropertyValue(p.replace(/[A-Z]/g, m => '-' + m.toLowerCase()));
    if (v) mirror.style[p] = v;
  }
  mirror.style.width = el.offsetWidth + 'px';
  const ws = cs.whiteSpace;
  mirror.style.whiteSpace = (ws === 'nowrap' || ws === 'normal' || ws === 'pre-line') ? 'pre' : ws;

  mirror.textContent = '';
  const parts = el.value.slice(0, pos).split('\n');
  for (let i = 0; i < parts.length; i++) {
    mirror.appendChild(document.createTextNode(parts[i]));
    if (i < parts.length - 1) mirror.appendChild(document.createElement('br'));
  }
  const marker = document.createElement('span');
  marker.textContent = '\u200b';
  mirror.appendChild(marker);

  const mr = mirror.getBoundingClientRect();
  const kr = marker.getBoundingClientRect();
  mirror.textContent = '';

  let x = rect.left + (kr.left - mr.left) - el.scrollLeft;
  let y = rect.top + (kr.top - mr.top) - el.scrollTop + (kr.height || 16);
  x = Math.min(Math.max(x, rect.left + 2), rect.right - 2);
  y = Math.min(Math.max(y, rect.top), rect.bottom);
  return { left: x, top: y, bottom: y, height: kr.height || 16 };
}

function measureWithSpan(range) {
  const span = document.createElement('span');
  span.textContent = '\u200b';
  span.style.cssText = 'display:inline;width:0;height:0;overflow:hidden;';
  let rect = null;
  try {
    range.insertNode(span);
    rect = span.getBoundingClientRect();
  } catch (e) { /* ignore */ }
  try {
    if (span.parentNode) span.parentNode.removeChild(span);
    range.normalize();
  } catch (e) { /* ignore */ }
  return rect;
}

function caretRectCE(el) {
  const sel = window.getSelection();
  if (!sel || !sel.rangeCount || !el.contains(sel.anchorNode)) return null;
  const range = sel.getRangeAt(0);
  let rect = null;
  const rects = range.getClientRects();
  if (rects.length) rect = rects[rects.length - 1];
  // Gecko quirk: collapsed ranges in empty lines can report nothing or a 0,0 rect
  if (!rect || (rect.width === 0 && rect.height === 0) || (rect.top === 0 && rect.left === 0)) {
    rect = measureWithSpan(range.cloneRange());
  }
  if (!rect) {
    const r = el.getBoundingClientRect();
    return { left: r.left + 4, top: r.top + 4, bottom: r.top + 4, height: 16 };
  }
  return { left: rect.left, top: rect.top, bottom: rect.top + (rect.height || 16), height: rect.height || 16 };
}

function caretRectFor(el, pos) {
  return isTextField(el) ? caretRectInput(el, pos) : caretRectCE(el);
}

/* -------------------------------------------------------------- insertion */

function fireInput(el, text, inputType) {
  let ev;
  try {
    ev = new InputEvent('input', { bubbles: true, cancelable: false, inputType: inputType || 'insertText', data: text });
  } catch (e) {
    ev = new Event('input', { bubbles: true });
  }
  el.dispatchEvent(ev);
}

function fireBeforeInput(el, text) {
  let ev;
  try {
    ev = new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: text });
  } catch (e) { return true; }
  return el.dispatchEvent(ev);
}

function insertIntoField(el, start, end, text) {
  if (isTextField(el)) {
    el.focus({ preventScroll: true });
    try {
      el.setRangeText(text, start, end, 'end');
    } catch (e) {
      el.value = el.value.slice(0, start) + text + el.value.slice(end);
      el.selectionStart = el.selectionEnd = start + text.length;
    }
    fireInput(el, text);
    return true;
  }
  /* contenteditable */
  el.focus({ preventScroll: true });
  const sel = window.getSelection();
  if (!sel) return false;
  try {
    const p1 = pointAt(el, start), p2 = pointAt(el, end);
    if (p1 && p2) {
      const r = document.createRange();
      r.setStart(p1.node, p1.offset);
      r.setEnd(p2.node, p2.offset);
      sel.removeAllRanges();
      sel.addRange(r);
    } else if (state.saved && state.saved.range) {
      sel.removeAllRanges();
      sel.addRange(state.saved.range);
    }
  } catch (e) { /* ignore */ }

  let ok = false;
  try { ok = !!(document.execCommand && document.execCommand('insertText', false, text)); }
  catch (e) { ok = false; }

  if (!ok) {
    try {
      if (!fireBeforeInput(el, text)) return false;   // editor cancelled it
      const range = sel.rangeCount ? sel.getRangeAt(0) : null;
      if (!range) return false;
      range.deleteContents();
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      fireInput(el, text);
      ok = true;
    } catch (e) { ok = false; }
  }
  return ok;
}

function saveFieldSelection(el) {
  if (isTextField(el)) {
    state.saved = { el, start: el.selectionStart ?? el.value.length, end: el.selectionEnd ?? el.value.length };
  } else {
    const sel = window.getSelection();
    state.saved = { el, range: sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null };
  }
}

/* ---------------------------------------------------------------- UI (shadow) */

let host = null, shadow = null, panel = null, listEl = null;
let wrapAuto = null, wrapPicker = null;
let searchEl = null, tabsEl = null, freqEl = null, gridEl = null, footEl = null;

const CSS = `
:host { all: initial; }
.ce-panel {
  position: fixed; display: flex; flex-direction: column;
  background: #2b2d31; color: #dbdee1;
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(0,0,0,.45), 0 0 0 1px rgba(0,0,0,.35);
  font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  font-size: 14px; line-height: 1.3; z-index: 2147483647; overflow: hidden;
  max-width: calc(100vw - 16px);
}
.ce-panel * { box-sizing: border-box; }
.ce-wrap { display: none; flex-direction: column; }
.ce-list { max-height: 300px; overflow-y: auto; padding: 6px; min-width: 250px; }
.ce-item { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 6px; cursor: pointer; white-space: nowrap; }
.ce-item.sel { background: #35373c; }
.ce-emoji { font-size: 20px; width: 26px; text-align: center; flex: none; }
.ce-emoji img { width: 22px; height: 22px; vertical-align: middle; }
.ce-code { color: #b5bac1; }
.ce-search { background: #1e1f22; border: 0; border-bottom: 1px solid #1e1f22; color: #dbdee1;
  padding: 10px 12px; font-size: 14px; outline: none; width: 100%; font-family: inherit; }
.ce-tabs { display: flex; gap: 2px; padding: 6px; overflow-x: auto; border-bottom: 1px solid #1e1f22;
  scrollbar-width: thin; }
.ce-tab { background: none; border: 0; color: #b5bac1; padding: 4px 8px; border-radius: 4px;
  cursor: pointer; font-size: 11px; white-space: nowrap; font-family: inherit; }
.ce-tab.sel { background: #35373c; color: #fff; }
.ce-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(36px, 1fr)); gap: 2px;
  padding: 8px; overflow-y: auto; max-height: 320px; }
.ce-cell { display: flex; align-items: center; justify-content: center; font-size: 22px;
  background: none; border: 0; border-radius: 6px; cursor: pointer; aspect-ratio: 1;
  color: inherit; padding: 0; font-family: inherit; }
.ce-cell.sel { background: #35373c; outline: 2px solid #5865f2; }
.ce-cell img { width: 26px; height: 26px; }
.ce-foot { display: flex; align-items: center; gap: 8px; padding: 6px 10px;
  border-top: 1px solid #1e1f22; color: #949ba4; font-size: 11px; flex-wrap: wrap; }
.ce-freq { display: none; gap: 2px; padding: 6px 8px 0; flex-wrap: wrap; }
.ce-fcell { display: flex; align-items: center; justify-content: center; font-size: 20px;
  background: none; border: 0; border-radius: 6px; cursor: pointer; width: 32px; height: 32px;
  color: inherit; padding: 0; font-family: inherit; }
.ce-fcell.sel { background: #35373c; outline: 2px solid #5865f2; }
.ce-fcell img { width: 24px; height: 24px; }
.ce-toast { position: fixed; right: 12px; bottom: 12px; background: #111214; color: #dbdee1;
  border: 1px solid #3f4147; padding: 8px 12px; border-radius: 8px; font-size: 12px;
  pointer-events: none; z-index: 2147483647; opacity: 1; transition: opacity .25s ease;
  box-shadow: 0 6px 16px rgba(0,0,0,.45); }
.ce-toast.out { opacity: 0; }
.ce-tone { display: inline-flex; gap: 3px; }
.ce-tone button { width: 16px; height: 16px; border-radius: 50%; border: 2px solid transparent;
  cursor: pointer; padding: 0; font-size: 0; }
.ce-tone button.sel { border-color: #fff; }
.ce-empty { padding: 14px; color: #949ba4; }
`;

function ensureHost() {
  if (host && host.isConnected) return true;
  try {
    host = document.createElement('div');
    host.setAttribute('data-colonemoji', '1');
    host.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;';
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = CSS;
    shadow.appendChild(style);
    panel = document.createElement('div');
    panel.className = 'ce-panel';
    panel.style.display = 'none';
    shadow.appendChild(panel);
    /* two persistent wrappers: re-rendering must never detach the focused
       search input (detaching blurs it and steals the user's typing) */
    wrapAuto = document.createElement('div');
    wrapAuto.className = 'ce-wrap';
    wrapPicker = document.createElement('div');
    wrapPicker.className = 'ce-wrap';
    panel.appendChild(wrapAuto);
    panel.appendChild(wrapPicker);
    (document.documentElement || document.body).appendChild(host);
    wirePanel();
    return true;
  } catch (e) { return false; }
}

function el_(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function emojiNode(item) {
  if (item.type === 'custom') {
    const img = document.createElement('img');
    img.src = customUrl(item);
    img.alt = ':' + item.name + ':';
    img.loading = 'lazy';
    return img;
  }
  return document.createTextNode(applyTone(item.ch, item.skin));
}

function wirePanel() {
  searchEl = el_('input', 'ce-search');
  searchEl.type = 'text';
  searchEl.setAttribute('data-colonemoji-input', '1');
  searchEl.setAttribute('placeholder', 'Search emoji…');
  searchEl.setAttribute('spellcheck', 'false');
  searchEl.addEventListener('input', () => {
    state.pickerQuery = searchEl.value;
    if (!state.pickerQuery && state.pickerCat === 'all') {
      state.pickerCat = state.recents.length ? 'recents' : 'Smileys & Emotion';
    }
    state.pickerSel = 0;
    renderPicker();
  });
  tabsEl = el_('div', 'ce-tabs');
  freqEl = el_('div', 'ce-freq');
  gridEl = el_('div', 'ce-grid');
  footEl = el_('div', 'ce-foot');
  wrapPicker.appendChild(searchEl);
  wrapPicker.appendChild(tabsEl);
  wrapPicker.appendChild(freqEl);
  wrapPicker.appendChild(gridEl);
  wrapPicker.appendChild(footEl);

  const cellClick = e => {
    const cell = e.target.closest ? e.target.closest('.ce-cell, .ce-fcell') : null;
    if (!cell) return;
    const i = Number(cell.dataset.i);
    if (!Number.isNaN(i)) { state.pickerSel = i; commitPicker(); }
  };
  const cellHover = e => {
    const cell = e.target.closest ? e.target.closest('.ce-cell, .ce-fcell') : null;
    if (!cell) return;
    const i = Number(cell.dataset.i);
    if (!Number.isNaN(i) && i !== state.pickerSel) { state.pickerSel = i; markSel(); }
  };
  freqEl.addEventListener('click', cellClick);
  freqEl.addEventListener('mousemove', cellHover);
  gridEl.addEventListener('click', cellClick);
  gridEl.addEventListener('mousemove', cellHover);
  footEl.addEventListener('click', e => {
    const b = e.target.closest ? e.target.closest('button[data-tone]') : null;
    if (!b) return;
    state.tone = Number(b.dataset.tone) | 0;
    api.storage.local.set({ tone: state.tone }).catch(() => {});
    renderPicker();
  });
}

/* ---------------------------------------------------------------- rendering */

let lastAnchor = null;   // last known caret rect + scroll, for picker repositioning

function place(rect) {
  if (!panel || !rect) return;
  lastAnchor = { rect: { left: rect.left, top: rect.top, bottom: rect.bottom, height: rect.height }, sy: window.scrollY };
  panel.style.display = 'flex';
  panel.style.visibility = 'hidden';
  const pw = panel.offsetWidth, ph = panel.offsetHeight;
  const vw = window.innerWidth, vh = window.innerHeight;
  let top = rect.top - ph - 8;
  if (top < 4) top = rect.bottom + 8;
  if (top + ph > vh - 4) top = Math.max(4, vh - ph - 4);
  let left = rect.left - 6;
  if (left + pw > vw - 4) left = vw - pw - 4;
  if (left < 4) left = 4;
  panel.style.top = Math.round(top) + 'px';
  panel.style.left = Math.round(left) + 'px';
  panel.style.visibility = '';
}

function hidePanel() {
  if (panel) panel.style.display = 'none';
  if (wrapAuto) { wrapAuto.textContent = ''; wrapAuto.style.display = 'none'; }
  if (wrapPicker) wrapPicker.style.display = 'none';
  /* never leave focus parked inside a hidden popup */
  if (shadow && shadow.activeElement) { try { shadow.activeElement.blur(); } catch (e) { /* ignore */ } }
  listEl = null;
}

function renderAuto() {
  if (!ensureHost()) return;
  wrapPicker.style.display = 'none';
  wrapAuto.style.display = 'flex';
  wrapAuto.textContent = '';
  listEl = wrapAuto;
  state.results.forEach((item, i) => {
    const row = el_('div', 'ce-item' + (i === state.sel ? ' sel' : ''));
    row.dataset.i = String(i);
    const e1 = el_('span', 'ce-emoji');
    e1.appendChild(emojiNode(item));
    row.appendChild(e1);
    row.appendChild(el_('span', 'ce-code', ':' + item.name + ':'));
    row.addEventListener('mousedown', ev => ev.preventDefault());
    row.addEventListener('click', () => { state.sel = i; commitAuto(); });
    row.addEventListener('mousemove', () => { if (state.sel !== i) { state.sel = i; markAutoSel(); } });
    listEl.appendChild(row);
  });
}

function markAutoSel() {
  if (!listEl) return;
  const rows = listEl.children;
  for (let i = 0; i < rows.length; i++) rows[i].classList.toggle('sel', i === state.sel);
  if (rows[state.sel] && rows[state.sel].scrollIntoView) rows[state.sel].scrollIntoView({ block: 'nearest' });
}

function renderPicker() {
  if (!ensureHost() || state.mode !== 'picker') return;
  wrapAuto.style.display = 'none';
  wrapAuto.textContent = '';
  wrapPicker.style.display = 'flex';
  /* searchEl is never re-created or re-attached: focus + typed text survive */

  /* tabs */
  const q = state.pickerQuery.trim().toLowerCase();
  tabsEl.textContent = '';
  const tabs = [['recents', 'Recents'], ['custom', 'Custom']]
    .concat(CATEGORIES.map(c => [c[0], c[1]]));
  for (const [id, label] of tabs) {
    const t = el_('button', 'ce-tab' + (!q && state.pickerCat === id ? ' sel' : ''), label);
    t.addEventListener('mousedown', ev => ev.preventDefault());
    t.addEventListener('click', () => {
      state.pickerCat = id;
      state.pickerQuery = '';
      state.pickerSel = 0;
      searchEl.value = '';
      renderPicker();
    });
    tabsEl.appendChild(t);
  }

  /* items */
  let items = [];
  let freq = [];
  if (q) {
    items = searchEmoji(q, MAX_PICKER_ITEMS);
  } else {
    if (state.pickerCat === 'recents') {
      for (const tok of state.recents) { const it = itemFromToken(tok); if (it) items.push(it); }
    } else if (state.pickerCat === 'custom') {
      items = state.custom.map(customItem);
      /* Feature 1: "Frequently used" row at the top, same frecency order
         (category tabs only — Recents is already a freshness list, and a
         search result list should stay pure) */
      freq = frequentItems(FREQUENT_COUNT);
      for (const it of freq) items = items.filter(x => x.name !== it.name);
    } else {
      items = state.index ? state.index.filter(it => it.cat === state.pickerCat) : [];
      freq = frequentItems(FREQUENT_COUNT);
      for (const it of freq) items = items.filter(x => x.name !== it.name);
    }
  }
  state.pickerFreq = freq;
  state.pickerItems = freq.concat(items);

  /* frequent row */
  freqEl.textContent = '';
  freqEl.style.display = freq.length ? 'flex' : 'none';
  freq.forEach((item, i) => {
    const cell = el_('button', 'ce-fcell');
    cell.type = 'button';
    cell.dataset.i = String(i);
    cell.title = ':' + item.name + ':';
    cell.appendChild(emojiNode(item));
    freqEl.appendChild(cell);
  });

  /* grid (indices are offset by the frequent row) */
  gridEl.textContent = '';
  if (!state.pickerItems.length) {
    gridEl.appendChild(el_('div', 'ce-empty', q ? 'No emoji found' : 'Nothing here yet'));
  }
  items.forEach((item, n) => {
    const i = n + freq.length;
    const cell = el_('button', 'ce-cell');
    cell.type = 'button';
    cell.dataset.i = String(i);
    cell.title = ':' + item.name + ':';
    cell.appendChild(emojiNode(item));
    gridEl.appendChild(cell);
  });
  if (state.pickerSel >= state.pickerItems.length) state.pickerSel = 0;
  markSel();

  /* footer: tones + hint */
  footEl.textContent = '';
  const toneWrap = el_('span', 'ce-tone');
  for (let t = 0; t < TONES.length; t++) {
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.tone = String(t);
    b.className = t === state.tone ? 'sel' : '';
    b.title = 'Skin tone: ' + TONE_NAMES[t];
    b.style.background = TONE_SWATCH[t];
    if (t > 0) { b.textContent = '\u{1F44D}' + TONES[t]; b.style.fontSize = '12px'; }
    toneWrap.appendChild(b);
  }
  footEl.appendChild(toneWrap);
  footEl.appendChild(el_('span', null, '\u2191\u2193\u2190\u2192 navigate · Enter/Tab insert · Esc close'));
}

function markSel() {
  if (!wrapPicker) return;
  const cells = wrapPicker.querySelectorAll('.ce-fcell, .ce-cell');
  cells.forEach(c => c.classList.toggle('sel', Number(c.dataset.i) === state.pickerSel));
  const cur = wrapPicker.querySelector('.sel');
  if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
}

/* ------------------------------------------------------- disabled-site notice */

const NOTICE_TEXT = 'ColonEmoji is off here (site has its own)';
const NOTICE_COOLDOWN = 60000;

function showDisabledNotice() {
  const now = Date.now();
  if (now - state.lastNoticeAt < NOTICE_COOLDOWN) return;
  state.lastNoticeAt = now;
  if (!ensureHost()) return;
  const old = shadow.querySelector('.ce-toast');
  if (old && old.parentNode) old.remove();
  const t = el_('div', 'ce-toast', NOTICE_TEXT);
  /* near the caret when we can measure it, otherwise bottom-right of the viewport */
  const rect = state.el ? safeCaretRect(state.el) : null;
  if (rect) {
    t.style.right = 'auto';
    t.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - 260)) + 'px';
    t.style.bottom = Math.max(8, window.innerHeight - rect.top + 8) + 'px';
  }
  shadow.appendChild(t);
  setTimeout(() => {
    t.classList.add('out');
    setTimeout(() => { if (t.parentNode) t.remove(); }, 300);
  }, 2000);
}

function safeCaretRect(el) {
  try {
    const info = caretInfo(el);
    return info ? caretRectFor(el, info.pos) : null;
  } catch (e) { return null; }
}

function shouldNotice(el) {
  if (!isBlocklisted()) return false;
  let info;
  try { info = caretInfo(el); } catch (e) { return false; }
  if (!info) return false;
  const t = parseTrigger(info.value, info.pos);
  if (!t) return false;
  return t.type === 'picker' || (t.type === 'auto' && t.q.length >= state.settings.minChars);
}

/* -------------------------------------------------------------- mode logic */

function reposition() {
  if (state.mode === 'none' || !state.el || !state.el.isConnected) return;
  if (state.mode === 'auto') {
    const info = caretInfo(state.el);
    if (!info) { closeAll(false); return; }
    place(caretRectFor(state.el, info.pos));
    return;
  }
  /* picker: re-measure, or translate the cached rect by the scroll delta
     (contenteditable selections are gone while the picker has focus) */
  let rect = null;
  if (isTextField(state.el)) {
    rect = caretRectFor(state.el, state.queryEnd);
  } else {
    rect = caretRectCE(state.el);
    if (!rect && lastAnchor) {
      rect = {
        left: lastAnchor.rect.left,
        top: lastAnchor.rect.top + (lastAnchor.sy - window.scrollY),
        bottom: lastAnchor.rect.bottom + (lastAnchor.sy - window.scrollY),
        height: lastAnchor.rect.height
      };
    }
  }
  if (rect) place(rect);
}

function onUpdate(el) {
  if (!siteEnabled()) {
    /* Feature 2: on blocklisted sites do nothing except the one-time notice */
    if (shouldNotice(el)) showDisabledNotice();
    if (state.mode !== 'none') closeAll(false);
    return;
  }
  /* closed shortcode (":name:") converts before normal trigger handling */
  if (tryClosedConvert(el)) return;
  const info = caretInfo(el);
  if (!info) return;
  const t = parseTrigger(info.value, info.pos);
  if (!t) { closeAll(false); return; }
  if (t.type === 'picker') { openPicker(el, t, info); return; }  if (state.mode === 'picker') return;
  if (t.q.length < state.settings.minChars) { closeAll(false); return; }

  ensureData().then(idx => {
    if (!idx || !isEditable(el) || state.mode === 'picker') return;
    const info2 = caretInfo(el);
    if (!info2) return;
    const t2 = parseTrigger(info2.value, info2.pos);
    if (!t2 || t2.type !== 'auto' || t2.q.length < state.settings.minChars) return;
    const res = searchEmoji(t2.q, MAX_RESULTS);
    if (!res.length) { closeAll(false); return; }
    if (t2.q !== state.lastQuery) { state.sel = 0; state.lastQuery = t2.q; }
    state.mode = 'auto';
    state.el = el;
    state.queryStart = t2.start;
    state.queryEnd = t2.end;
    state.results = res;
    if (state.sel >= res.length) state.sel = 0;
    renderAuto();
    place(caretRectFor(el, info2.pos));
  });
}

function openPicker(el, t, info) {
  if (!ensureHost()) return;
  const fresh = state.mode !== 'picker';
  state.mode = 'picker';
  state.el = el;
  state.queryStart = t.start;
  state.queryEnd = t.end;
  state.pickerQuery = t.q || '';
  state.pickerSel = 0;
  if (fresh) {
    saveFieldSelection(el);
    if (!state.pickerQuery) state.pickerCat = state.recents.length ? 'recents' : 'Smileys & Emotion';
  }
  searchEl.value = state.pickerQuery;
  renderPicker();
  place(caretRectFor(el, info.pos));
  ensureData().then(() => { if (state.mode === 'picker') renderPicker(); });
  try { searchEl.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
}

function restoreFocus(restoreRange) {
  const s = state.saved;
  if (!s || !s.el || !s.el.isConnected) return;
  try {
    s.el.focus({ preventScroll: true });
    if (restoreRange && !isTextField(s.el) && s.range && s.range.startContainer && s.range.startContainer.isConnected) {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(s.range);
    }
  } catch (e) { /* ignore */ }
}

/* refocus: focus the original field again.
   restoreRange: also put the caret back where it was (Esc-style cancel). */
function closeAll(refocus, restoreRange) {
  const wasOpen = state.mode !== 'none';
  state.mode = 'none';
  state.results = [];
  state.pickerItems = [];
  state.sel = 0;
  state.pickerSel = 0;
  state.lastQuery = null;
  hidePanel();
  lastAnchor = null;
  if (wasOpen && refocus) restoreFocus(!!restoreRange);
  state.saved = null;
  state.el = null;
}

function commitAuto() {
  const item = state.results[state.sel];
  if (!item) return closeAll(false);
  const el = state.el;
  const text = insertTextFor(item);
  insertIntoField(el, state.queryStart, state.queryEnd, text);
  pushRecent(item);
  bumpUsage(item, state.lastQuery);   // Feature 1: learn prefix -> emoji
  closeAll(false);
  ensureData();
}

function commitPicker() {
  const item = state.pickerItems[state.pickerSel];
  if (!item) return closeAll(false);
  const el = state.el;
  const text = insertTextFor(item);
  insertIntoField(el, state.queryStart, state.queryEnd, text);
  pushRecent(item);
  bumpUsage(item, (state.pickerQuery || '').trim().toLowerCase());
  closeAll(false);   // focus + caret are already correct after insertion
}

function moveAutoSel(d) {
  if (!state.results.length) return;
  state.sel = (state.sel + d + state.results.length) % state.results.length;
  markAutoSel();
}

function movePickerSel(key) {
  const n = state.pickerItems.length;
  if (!n) return;
  const fcount = state.pickerFreq ? state.pickerFreq.length : 0;
  const cells = gridEl ? gridEl.querySelectorAll('.ce-cell') : [];
  let cols = 1;
  if (cells.length > 1) {
    const a = cells[0].getBoundingClientRect(), b = cells[1].getBoundingClientRect();
    cols = b.left > a.left ? Math.max(1, Math.round(gridEl.clientWidth / (a.width || 40))) : 1;
  }
  let i = state.pickerSel;
  const inRow = i < fcount;   // frequent row is a single line above the grid
  if (key === 'Home') i = 0;
  else if (key === 'End') i = n - 1;
  else if (key === 'PageDown') i += cols * 5;
  else if (key === 'PageUp') i -= cols * 5;
  else if (key === 'ArrowRight') i = inRow ? Math.min(i + 1, fcount - 1) : i + 1;
  else if (key === 'ArrowLeft') i = inRow ? Math.max(0, i - 1) : (i - 1 < fcount ? fcount : i - 1);
  else if (key === 'ArrowDown') i = inRow ? Math.min(fcount, n - 1) : i + cols;
  else if (key === 'ArrowUp') i = (i - cols < fcount) ? Math.max(0, fcount - 1) : i - cols;
  i = Math.min(Math.max(i, 0), n - 1);
  state.pickerSel = i;
  markSel();
}

/* ------------------------------------------------------------------- events */

/* --------------------------------------------- closed-shortcode conversion */

/* parseClosedTrigger(":fire:", 6) -> { name:"fire", start:0, end:6 }
   Pure, so the harness can test it without a DOM. */
function parseClosedTrigger(text, pos, trigger) {
  const trig = trigger || (state.settings && state.settings.trigger) || ':';
  if (pos < 3) return null;
  if (text[pos - 1] !== trig) return null;          // caret must sit right after the closing trigger
  let i = pos - 2, n = 1;
  while (i >= 0 && n < 40 && WORD_RE.test(text[i])) { i--; n++; }
  if (i < 0 || text[i] !== trig) return null;       // no opening trigger before the name
  const name = text.slice(i + 1, pos - 1).toLowerCase();
  if (name.length < 2) return null;
  return { name, start: i, end: pos };
}

let restoring = false;   // true while writing the undo restore back into the field

function tryClosedConvert(el) {
  if (!state.settings.closeShortcode) return false;
  const info = caretInfo(el);
  if (!info) return false;
  const t = parseClosedTrigger(info.value, info.pos);
  if (!t) return false;
  if (!state.index) {        // data not fetched yet: convert as soon as it lands
    ensureData().then(() => { if (tryClosedConvert(el)) closeAll(false); });
    return false;
  }
  const item = itemByName(t.name);
  if (!item) return false;
  const text = insertTextFor(item);
  if (!insertIntoField(el, t.start, t.end, text)) return false;
  pushRecent(item);
  bumpUsage(item, t.name);
  state.undo = {
    el,
    text: info.value.slice(t.start, t.end),   // the original ":name:"
    selStart: t.start,
    selEnd: t.start + text.length             // caret sits here after the emoji
  };
  closeAll(false);
  return true;
}

/* Backspace immediately after a conversion: put ":name:" back and select it, so
   the next Backspace clears it entirely (Discord-style two-step undo). */
function undoClosedConvert(e) {
  const u = state.undo;
  if (!u) return false;
  const el = u.el;
  if (!el || !el.isConnected || document.activeElement !== el) { state.undo = null; return false; }
  const info = caretInfo(el);
  /* only if nothing changed: caret still right after the emoji, emoji still last */
  if (!info || info.pos !== u.selEnd || info.value.length !== u.selEnd) { state.undo = null; return false; }
  e.preventDefault();
  e.stopPropagation();
  state.undo = null;
  restoring = true;
  try {
    insertIntoField(el, u.selStart, u.selEnd, u.text);
    if (isTextField(el)) {
      try { el.focus({ preventScroll: true }); el.setSelectionRange(u.selStart, u.selStart + u.text.length); }
      catch (err) { /* ignore */ }
    } else {
      const p1 = pointAt(el, u.selStart), p2 = pointAt(el, u.selStart + u.text.length);
      const sel = window.getSelection();
      if (p1 && p2 && sel) {
        const r = document.createRange();
        r.setStart(p1.node, p1.offset);
        r.setEnd(p2.node, p2.offset);
        sel.removeAllRanges();
        sel.addRange(r);
      }
    }
  } finally {
    restoring = false;
  }
  return true;
}

function onKey(e) {
  if (e.isComposing || e.keyCode === 229 || state.composing) return;

  /* Feature 3: global toggle shortcut (works in both engines without a
     background script, which MV3 can't share between Chromium and Firefox) */
  if (e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && String(e.key).toLowerCase() === 'e') {
    e.preventDefault();
    e.stopPropagation();
    state.settings.enabled = !state.settings.enabled;
    saveSettings();
    if (!state.settings.enabled) closeAll(false);
    return;
  }

  /* Backspace right after a closed-shortcode conversion reverts it */
  if (e.key === 'Backspace' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey &&
      undoClosedConvert(e)) return;

  if (state.mode === 'none') return;
  const k = e.key;

  if (k === 'Escape') { state.undo = null; e.preventDefault(); e.stopPropagation(); closeAll(true, true); return; }

  if (state.mode === 'picker') {
    if (['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown'].includes(k)) {
      e.preventDefault(); e.stopPropagation(); movePickerSel(k); return;
    }
    if (k === 'Enter' || k === 'Tab') {
      const want = state.settings.insertKeys;
      if (want === 'both' || want === k.toLowerCase()) { e.preventDefault(); e.stopPropagation(); commitPicker(); }
      else if (k === 'Enter') { e.preventDefault(); e.stopPropagation(); closeAll(true, true); }
      else closeAll(false);   // Tab not used for insert: let focus move on
      return;
    }
    return;
  }

  /* autocomplete mode */
  if (k === 'ArrowDown' || k === 'ArrowUp') {
    e.preventDefault(); e.stopPropagation(); moveAutoSel(k === 'ArrowDown' ? 1 : -1); return;
  }
  if (k === 'Enter' || k === 'Tab') {
    const want = state.settings.insertKeys;
    if ((want === 'both' || want === k.toLowerCase()) && state.results.length) {
      e.preventDefault(); e.stopPropagation(); commitAuto(); return;
    }
    closeAll(false);   // pass the key through (form submit / focus change)
  }
}

let rafPending = false;
function scheduleReposition() {
  if (rafPending || state.mode === 'none') return;
  rafPending = true;
  requestAnimationFrame(() => { rafPending = false; reposition(); });
}

function onInputEvent(e) {
  if (state.composing || e.isComposing) return;
  const t = realTarget(e);
  if (t === host) return;                 // our own shadow input (handled there)
  state.undo = null;                      // any new input invalidates the one-step undo
  if (restoring) return;                  // our own undo write-back: keep the selection
  if (!isEditable(t)) { if (state.mode === 'auto') closeAll(false); return; }
  onUpdate(t);
}

function onSelChange() {
  if (state.mode !== 'auto' || state.composing) return;
  const el = state.el;
  if (document.activeElement !== el) { closeAll(false); return; }
  /* caret moved out of the query (arrow keys, click, selection) -> dismiss */
  const info = caretInfo(el);
  if (!info) { closeAll(false); return; }
  const t = parseTrigger(info.value, info.pos);
  if (!t || t.type !== 'auto' || t.start !== state.queryStart ||
      t.end !== state.queryEnd || t.q !== state.lastQuery) closeAll(false);
}

function onDocDown(e) {
  state.undo = null;                      // clicking elsewhere ends the undo window
  if (state.mode === 'none') return;
  const t = realTarget(e);
  if (t === host || (host && host.contains(t))) return;
  if (t === state.el) return;   // click inside the anchored field: caret logic decides
  closeAll(false);
}

document.addEventListener('keydown', onKey, true);
document.addEventListener('input', onInputEvent, true);
document.addEventListener('compositionstart', () => { state.composing = true; }, true);
document.addEventListener('compositionend', () => {
  state.composing = false;
  const a = document.activeElement;
  if (a && isEditable(a) && siteEnabled()) onUpdate(a);   // IME commit may not re-fire input
}, true);
document.addEventListener('selectionchange', onSelChange);
window.addEventListener('scroll', scheduleReposition, true);
window.addEventListener('resize', scheduleReposition);
document.addEventListener('mousedown', onDocDown, true);
window.addEventListener('blur', () => closeAll(false));

/* -------------------------------------------------------- toolbar messaging */

api.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return false;
  if (msg.type === 'colonemoji:status') {
    sendResponse({
      ok: true,
      enabled: !!state.settings.enabled,
      host: location.hostname,
      siteDisabled: isSiteDisabled(location.hostname),
      forceEnabled: isForceEnabled(location.hostname),
      blocklisted: isBlocklisted(),
      siteOn: siteEnabled()
    });
  } else if (msg.type === 'colonemoji:setEnabled') {
    state.settings.enabled = !!msg.value;
    saveSettings();
    if (!state.settings.enabled) closeAll(false);
    sendResponse({ ok: true });
  } else if (msg.type === 'colonemoji:setSite') {
    const host2 = location.hostname;
    const list = (state.settings.disabledSites || []).slice();
    const idx = list.findIndex(x => String(x).toLowerCase() === host2.toLowerCase());
    if (msg.value && idx < 0) list.push(host2);
    if (!msg.value && idx >= 0) list.splice(idx, 1);
    state.settings.disabledSites = list;
    saveSettings();
    if (!siteEnabled()) closeAll(false);
    sendResponse({ ok: true });
  } else if (msg.type === 'colonemoji:setForce') {
    /* Feature 2: "Enable here anyway" override (enabledSites) */
    const host2 = location.hostname;
    const list = (state.settings.enabledSites || []).slice();
    const idx = list.findIndex(x => String(x).toLowerCase() === host2.toLowerCase());
    if (msg.value && idx < 0) list.push(host2);
    if (!msg.value && idx >= 0) list.splice(idx, 1);
    state.settings.enabledSites = list;
    saveSettings();
    if (!siteEnabled()) closeAll(false);
    sendResponse({ ok: true });
  }
  return false;
});

/* --------------------------------------------------------------------- init */

loadAll().then(() => ensureData());
