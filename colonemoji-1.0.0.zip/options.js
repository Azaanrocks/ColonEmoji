'use strict';
/* ColonEmoji options page — cross-browser (promise-based WebExtension APIs). */
const api = globalThis.browser ?? globalThis.chrome;

const DEFAULTS = {
  trigger: ':',
  pickerChar: '',
  minChars: 2,
  insertFormat: 'emoji',
  insertKeys: 'both',
  customInsertFormat: 'markup',
  disabledSites: [],
  enabledSites: [],
  blockedSites: [],
  learnRanking: true,
  customAliases: {},
  hiddenEmojis: [],
  closeShortcode: true,
  enabled: true
};

const $ = id => document.getElementById(id);
let settings = Object.assign({}, DEFAULTS);
let custom = [];

/* keep in sync with content.js defaults */
const DEFAULT_BLOCKLIST = [
  'discord.com', 'slack.com', 'github.com', 'gitlab.com', 'notion.so', 'linear.app',
  'web.whatsapp.com', 'teams.microsoft.com', 'teams.live.com', 'teams.cloud.microsoft',
  'chat.google.com', 'mail.google.com', 'web.telegram.org', 'app.element.io',
  'twitch.tv', 'zulipchat.com'
];
const DEFAULT_ALIASES = { palestine: '\u{1F1F5}\u{1F1F8}', palestinian: '\u{1F1F5}\u{1F1F8}', palastine: '\u{1F1F5}\u{1F1F8}' };
const DEFAULT_HIDDEN = [];

function toast(msg, err) {
  const s = $('status');
  s.textContent = msg;
  s.className = 'show' + (err ? ' err' : '');
  setTimeout(() => { s.className = ''; }, 1800);
}

function save() {
  return api.storage.sync.set({ settings }).then(() => toast('Saved'), e => toast('Save failed', true));
}

function saveCustom() {
  return api.storage.local.set({ customEmojis: custom }).then(() => { renderTable(); toast('Saved'); });
}

/* ------------------------------------------------------------ parse inputs */

function readForm() {
  settings.trigger = ($('trigger').value || ':').slice(0, 1);
  settings.pickerChar = ($('pickerChar').value || '').slice(0, 1);
  if (settings.pickerChar === settings.trigger) settings.pickerChar = '';
  settings.minChars = Math.min(6, Math.max(1, parseInt($('minChars').value, 10) || 2));
  settings.insertKeys = $('insertKeys').value;
  settings.insertFormat = $('insertFormat').value;
  settings.customInsertFormat = $('customInsertFormat').value;
  settings.enabled = $('enabled').checked;
  settings.learnRanking = $('learnRanking').checked;
  settings.disabledSites = $('disabledSites').value
    .split('\n').map(s => s.trim()).filter(Boolean);
  settings.blockedSites = $('blockedSites').value
    .split('\n').map(s => s.trim()).filter(Boolean);
}

function fillForm() {
  $('trigger').value = settings.trigger;
  $('pickerChar').value = settings.pickerChar || '';
  $('minChars').value = settings.minChars;
  $('insertKeys').value = settings.insertKeys;
  $('insertFormat').value = settings.insertFormat;
  $('customInsertFormat').value = settings.customInsertFormat;
  $('enabled').checked = !!settings.enabled;
  $('learnRanking').checked = settings.learnRanking !== false;
  $('disabledSites').value = (settings.disabledSites || []).join('\n');
  $('blockedSites').value = (settings.blockedSites && settings.blockedSites.length
    ? settings.blockedSites : DEFAULT_BLOCKLIST).join('\n');
  renderAliasRows();
  renderHiddenRows();
}

/* ------------------------------------------------- alias / hidden row editors */

function syncAliases() {
  const out = {};
  for (const row of $('aliasRows').children) {
    const a = row.querySelector('.a-alias').value.trim().toLowerCase();
    const v = row.querySelector('.a-char').value.trim();
    if (a && v) out[a] = v;
  }
  settings.customAliases = out;
  save();
}

function renderAliasRows() {
  const wrap = $('aliasRows');
  wrap.textContent = '';
  const entries = Object.keys(settings.customAliases || {}).map(a => [a, settings.customAliases[a]]);
  if (!entries.length) addAliasRow('', '');
  for (const [a, v] of entries) addAliasRow(a, v);
}

function addAliasRow(alias, ch) {
  const row = document.createElement('div');
  row.className = 'rowline';
  const i1 = document.createElement('input');
  i1.type = 'text'; i1.className = 'a-alias short'; i1.placeholder = 'alias'; i1.value = alias;
  const i2 = document.createElement('input');
  i2.type = 'text'; i2.className = 'a-char'; i2.placeholder = 'emoji character'; i2.value = ch;
  const del = document.createElement('button');
  del.className = 'small danger'; del.type = 'button'; del.textContent = '✕';
  del.addEventListener('click', () => { row.remove(); syncAliases(); });
  i1.addEventListener('change', syncAliases);
  i2.addEventListener('change', syncAliases);
  row.appendChild(i1); row.appendChild(i2); row.appendChild(del);
  $('aliasRows').appendChild(row);
}

function syncHidden() {
  settings.hiddenEmojis = [...$('hiddenRows').children]
    .map(row => row.querySelector('input').value.trim()).filter(Boolean);
  save();
}

function renderHiddenRows() {
  const wrap = $('hiddenRows');
  wrap.textContent = '';
  const list = (settings.hiddenEmojis && settings.hiddenEmojis.length)
    ? settings.hiddenEmojis : DEFAULT_HIDDEN.slice();
  if (!list.length) addHiddenRow('');
  for (const v of list) addHiddenRow(v);
}

function addHiddenRow(v) {
  const row = document.createElement('div');
  row.className = 'rowline';
  const i = document.createElement('input');
  i.type = 'text'; i.placeholder = 'shortcode or emoji character'; i.value = v;
  const del = document.createElement('button');
  del.className = 'small danger'; del.type = 'button'; del.textContent = '✕';
  del.addEventListener('click', () => { row.remove(); syncHidden(); });
  i.addEventListener('change', syncHidden);
  row.appendChild(i); row.appendChild(del);
  $('hiddenRows').appendChild(row);
}

/* --------------------------------------------------------- custom emoji I/O */

function url(c) {
  return 'https://cdn.discordapp.com/emojis/' + c.id + (c.animated ? '.gif' : '.png');
}

function renderTable() {
  const tb = $('cTable').querySelector('tbody');
  tb.textContent = '';
  if (!custom.length) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.textContent = 'No custom emoji yet.';
    td.style.color = '#949ba4';
    tr.appendChild(td);
    tb.appendChild(tr);
    return;
  }
  for (let i = 0; i < custom.length; i++) {
    const c = custom[i];
    const tr = document.createElement('tr');

    const td0 = document.createElement('td');
    td0.className = 'prev';
    const img = document.createElement('img');
    img.src = url(c);
    img.alt = '';
    img.onerror = () => { img.replaceWith(document.createTextNode('❓')); };
    td0.appendChild(img);
    tr.appendChild(td0);

    const td1 = document.createElement('td');
    td1.textContent = ':' + c.name + ':';
    tr.appendChild(td1);

    const td2 = document.createElement('td');
    td2.textContent = c.id + (c.animated ? ' (animated)' : '');
    td2.style.color = '#949ba4';
    tr.appendChild(td2);

    const td3 = document.createElement('td');
    td3.style.textAlign = 'right';
    const btn = document.createElement('button');
    btn.className = 'small danger';
    btn.textContent = 'Delete';
    btn.addEventListener('click', () => { custom.splice(i, 1); saveCustom(); });
    td3.appendChild(btn);
    tr.appendChild(td3);

    tb.appendChild(tr);
  }
}

function normName(n) {
  return String(n).trim().toLowerCase().replace(/^:|:$/g, '').replace(/[^a-z0-9_+-]/g, '');
}

function addOne(name, id, animated, seen) {
  name = normName(name);
  id = String(id || '').trim();
  if (!/^\d{5,25}$/.test(id)) return false;
  if (!name) return false;
  const key = name;
  const existing = custom.findIndex(c => c.name === name);
  const obj = { name, id, animated: !!animated };
  if (existing >= 0) custom[existing] = obj;
  else custom.push(obj);
  if (seen) seen.add(key);
  return true;
}

function parseBulk(text) {
  let added = 0;
  const trimmed = text.trim();
  if (!trimmed) return 0;

  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const data = JSON.parse(trimmed);
      for (const e of (Array.isArray(data) ? data : [data])) {
        if (e && addOne(e.name, e.id, e.animated)) added++;
      }
      return added;
    } catch (e) { /* fall through to line parsing */ }
  }

  for (const line of trimmed.split(/[\n,]+/)) {
    const l = line.trim();
    if (!l) continue;
    let m;
    if ((m = l.match(/^<a?:([A-Za-z0-9_+-]+):(\d+)>?$/))) { if (addOne(m[1], m[2], m[0].startsWith('<a:'))) added++; continue; }
    if ((m = l.match(/^([A-Za-z0-9_+-]+)[:\s]+(\d{5,25})\s*(animated|gif|a)?$/i))) { if (addOne(m[1], m[2], !!m[3])) added++; continue; }
    try {
      const e = JSON.parse(l);
      if (e && addOne(e.name, e.id, e.animated)) added++;
    } catch (e) { /* skip junk lines */ }
  }
  return added;
}

/* ------------------------------------------------------------------- wiring */

function wire() {
  for (const id of ['trigger', 'pickerChar', 'minChars', 'insertKeys', 'insertFormat',
    'customInsertFormat', 'enabled', 'learnRanking', 'disabledSites', 'blockedSites']) {
    $(id).addEventListener('change', () => { readForm(); save(); });
  }
  $('addAlias').addEventListener('click', () => { addAliasRow('', ''); const rows = $('aliasRows').querySelectorAll('input'); rows[rows.length - 2].focus(); });
  $('addHidden').addEventListener('click', () => { addHiddenRow(''); const rows = $('hiddenRows').querySelectorAll('input'); rows[rows.length - 1].focus(); });
  $('resetUsage').addEventListener('click', () => {
    api.storage.local.set({ usage: {}, prefixPicks: {}, recents: [] }).then(() => toast('Learned usage cleared'), () => toast('Reset failed', true));
  });
  $('resetBlocked').addEventListener('click', () => {
    $('blockedSites').value = DEFAULT_BLOCKLIST.join('\n');
    readForm(); save();
  });
  $('resetHidden').addEventListener('click', () => {
    settings.hiddenEmojis = DEFAULT_HIDDEN.slice();
    renderHiddenRows(); save();
  });
  $('cAdd').addEventListener('click', () => {
    if (addOne($('cName').value, $('cId').value, $('cAnim').checked)) {
      $('cName').value = ''; $('cId').value = ''; $('cAnim').checked = false;
      saveCustom();
    } else toast('Need a name and a numeric ID', true);
  });
  $('cBulkAdd').addEventListener('click', () => {
    const n = parseBulk($('cBulk').value);
    if (n) { $('cBulk').value = ''; saveCustom(); } else toast('Nothing parsed', true);
  });
  $('cExport').addEventListener('click', () => {
    const text = JSON.stringify(custom, null, 2);
    $('cBulk').value = text;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => toast('Copied JSON'), () => toast('JSON shown in the box'));
    } else toast('JSON shown in the box');
  });
  $('resetAll').addEventListener('click', () => {
    if (!confirm('Reset all ColonEmoji settings, learned usage and custom emoji?')) return;
    settings = Object.assign({}, DEFAULTS, {
      blockedSites: DEFAULT_BLOCKLIST.slice(),
      customAliases: Object.assign({}, DEFAULT_ALIASES),
      hiddenEmojis: DEFAULT_HIDDEN.slice()
    });
    custom = [];
    api.storage.sync.set({ settings });
    api.storage.local.set({ customEmojis: [], recents: [], tone: 0, usage: {}, prefixPicks: {} });
    fillForm();
    renderTable();
    toast('Reset done');
  });
}

Promise.all([
  api.storage.sync.get({ settings: DEFAULTS }).then(r => { settings = Object.assign({}, DEFAULTS, r.settings || {}); }),
  api.storage.local.get({ customEmojis: [] }).then(r => { custom = Array.isArray(r.customEmojis) ? r.customEmojis : []; })
]).catch(() => {}).then(() => {
  fillForm();
  renderTable();
  wire();
});
